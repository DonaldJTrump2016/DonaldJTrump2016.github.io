/*
�̳���Menu()�����У����� 
*/
#include<bits/stdc++.h>
#include"WAI.hpp"
#define guideMap "Warlords1.0.2guide.cws"
#pragma GCC optimize("Ofast,no-stack-protector")
using namespace std;
int nCount;
const string save1="Warlords1.0.2sv1.cws",save2="Warlords1.0.2sv2.cws",save3="Warlords1.0.2sv3.cws";
struct land {
	int armyCount,ownPlayer,landKind;
	bool operator == (land &a){
		if(this->ownPlayer!=a.ownPlayer||this->landKind!=a.landKind)return 0;
		int t1=this->armyCount,t2=a.armyCount;
		while(t1>9)t1/=10;
		while(t2>9)t2/=10;
		if(t1==t2)return 1;
		return 0;
	}
} gMap[101][101],lMap[101][101];
struct moveUnit {
	int x,y;
};
int mSize,citySpeed,landSpeed,cityCount,mountCount,towerCount,waCount,armyCount[1000],landCount[1000],aiTryCount;//����˼��
int capitalX[1000],capitalY[1000],playerCount,optX,optY,aiLevel,totalArmy,totalLand,nowCount,aliveAiCount;//�׶�λ��,�������,���λ��,AI�ȼ�
deque <moveUnit> aiPath[1000];//�洢AI��·��
int landVis[101][101],warFog[101][101],needRef[101][101],lFog[101][101],ifFog,ifEnd,aiHelp=0,backFromSave;//AI���������;ս������
void gInit();//���ɵ�ͼ
void ArmyMove(int x,int y,int dx,int dy);//�ƶ�
void AiDfs(int p,int x,int y,int dx,int dy);//DFS
void AiFindPath(int p,int x,int y,int dx,int dy);//AI����·��
void AiCheckCapital(int p);//AI����׶��Ƿ���ڿ���
void AiSuddenAttack(int p);//AI͵Ϯ
void AiExband(int p);//AI����
void DoAiQueue(int p);//ִ��AI�ж�
void AiDecide();//AI��������
void gPlus();//�ӱ�
void LoadHisMap();//������ʷ 
void SpawnNewPlayer(int x,int y);//��������� 
void SpawnNewPlayers();//�ж��Ƿ��������� 
void FindPlayerTeam(int f);//���ǲ��鼯������ 
void PlayerKill(int k,int d); //��ɱ 
void BuildLand(int x,int y,int kind);//�������
void GetArmyCounts();//��ȡ����������Ϣ
void GetLandCounts();//��ȡ����������Ϣ
void LoadWarFog();//����ս������
void gotoxy(int x,int y);//�ƶ����
void color(int t,int b);//Ϳɫ
void GameMain();//����Ϸ
void PlayerDo(bool only);//��Ҳ���
void DoAiAndMap();//���̲߳���AI����� 
int GameEnd();//�ж���Ϸ�Ƿ����
void GameStart();//��ʼ��Ϸ
void PrintMap();//�����ͼ
void PrintLand(int i,int j);//�������
void PrintArmyCount(int n);//�����������
void SaveMap();//�����ͼ
void Menu();//���˵� 
void LoadMap();//��ȡ�浵��ؿ� ��
void EditLand(int x,int y);//�༭��ͼ 
unsigned int Randn(unsigned int seed);//�������
bool RandPer(int per,int seed);//�ٷֱȺ���
unsigned int Randn(unsigned int seed) {
	srand(time(NULL)+seed*seed);
	unsigned int ans=rand();
	srand(mSize);
	ans+=rand();
	srand(armyCount[1]+gMap[rand()%mSize+1][rand()%mSize+1].armyCount); 
	ans+=rand();
	srand(gMap[rand()%mSize+1][rand()%mSize+1].armyCount);
	srand(nCount+gMap[rand()%mSize+1][rand()%mSize+1].landKind);
	return ans+rand();
}
bool RandPer(int per,int seed) {
	if(per>=100)return true;
	if(per<=0)return false;
	int p=rand();
	int temp=Randn(per+nCount+Randn(per+1)+p+seed*seed)%100;
	srand(time(NULL)+seed*seed);
	temp+=rand()*seed;
	temp%=100;
	if(temp<=per)return true;
	else return false;
}
void GameStart() {//�벻Ҫ���������޷������ĵ�ͼ���ɣ�����2x2��ͼ5����ң�,��Ȼ�Ῠ�������.��Ұ����Լ��� 
	system("cls");
	printf("�������������\n");
	scanf("%d",&playerCount);
	printf("�����ͼ��С��\n");
	scanf("%d",&mSize);
	printf("������������ٶȡ�\n");
	scanf("%d",&citySpeed);
	printf("�����������������\n");
	scanf("%d",&landSpeed);
	printf("�������������\n");
	scanf("%d",&cityCount);
	printf("�����ϰ�������\n");
	scanf("%d",&mountCount);
	printf("�����ݵ�������\n");
	scanf("%d",&waCount);
	printf("���������������\n");
	scanf("%d",&towerCount);
	printf("����AI���ֵȼ���(������,1Ϊ��ƽ����,3��AI�ݵؿ��Բ���,4��AI��ñ�������,6��AI���������Բ���)\n");
	scanf("%d",&aiLevel);
	printf("�Ƿ���ս��������������1,��������0��\n");
	scanf("%d",&ifFog);
	printf("�Ƿ���ʧ�ܺ��Զ�������Ϸ��������1,��������0��\n");
	scanf("%d",&ifEnd);
}
void gInit() {
	aliveAiCount=playerCount-1;
	int randx,randy;
	for(int i=1; i<=mSize; i++) {
		for(int j=1; j<=mSize; j++) {
			gMap[i][j].landKind=normalLand;
		}
	}
	for(int i=1; i<=playerCount; i++) {
		randx=Randn(i)%mSize+1;
		randy=Randn(i+97)%mSize+1;
		capitalX[i]=randx;
		capitalY[i]=randy;
		gMap[randx][randy].landKind=playerCapital;
		gMap[randx][randy].ownPlayer=i;
	}
	for(int i=1; i<=cityCount; i++) {
		randx=Randn(i+12)%mSize+1;
		randy=Randn(i+27)%mSize+1;
		for(int j=1; j<=playerCount; j++) {
			while(randx==capitalX[j]&&randy==capitalY[j]) {
				srand(rand());
				randx=Randn(i+j+2)%mSize+1;
				randy=Randn(i+j+1)%mSize+1;
			}
		}
		gMap[randx][randy].landKind=city;
		gMap[randx][randy].armyCount=Randn(i+3)%citySpeed*10+citySpeed*40;
	}
	for(int i=1; i<=waCount; i++) {
		randx=Randn(i+233)%mSize+1;
		randy=Randn(i+87)%mSize+1;
		for(int j=1; j<=playerCount; j++) {
			while(randx==capitalX[j]&&randy==capitalY[j]) {
				srand(rand());
				randx=Randn(j+11)%mSize+1;
				randy=Randn(j+14)%mSize+1;
			}
		}
		gMap[randx][randy].landKind=waLand;
	}
	for(int i=1; i<=towerCount; i++) {
		randx=Randn(i+213)%mSize+1;
		randy=Randn(i+27)%mSize+1;
		for(int j=1; j<=playerCount; j++) {
			while(randx==capitalX[j]&&randy==capitalY[j]) {
				srand(rand());
				randx=Randn(j+12)%mSize+1;
				randy=Randn(j+13)%mSize+1;
			}
		}
		gMap[randx][randy].landKind=tower;
		gMap[randx][randy].armyCount=Randn(i+3)%citySpeed*8+citySpeed*32;
	}
	for(int i=1; i<=mountCount; i++) {
		randx=Randn(i+234)%mSize+1;
		randy=Randn(i+57)%mSize+1;
		for(int j=1; j<=playerCount; j++) {
			while(randx==capitalX[j]&&randy==capitalY[j]) {
				srand(rand());
				randx=Randn(i+2)%mSize+1;
				randy=Randn(i+1)%mSize+1;
			}
		}
		gMap[randx][randy].landKind=mountLand;
	}
	optX=capitalX[1];
	optY=capitalY[1];
}
void PrintArmyCount(int val) {
	if(val<0) printf(" -");
	else if(val<10) printf("%d ",val);
	else if(val<100) printf("%d",val);
	else if(val<1000) printf("%dH",val/100);
	else if(val<10000) printf("%dK",val/1000);
	else if(val<100000) printf("%dW",val/10000);
	else if(val<1000000) printf("%dT",val/100000);
	else if(val<10000000) printf("%dM",val/1000000);
	else if(val<100000000) printf("%dQ",val/10000000);
	else if(val<1000000000) printf("%dE",val/100000000);
	else if(val<2147483647) printf("%dB",val/1000000000);
}
void PrintLand(int i,int j) {
	if(!needRef[i][j])return; 
	gotoxy(i-1,j*3);
	color(7,0);
	if(!warFog[i][j]) {
		color(0,8);
		putchar(' ');putchar('~');putchar(i==optX&&j==optY?'<':' ');
		return;
	}
	if(gMap[i][j].ownPlayer%16==0&&gMap[i][j].armyCount==0&&gMap[i][j].landKind==normalLand) {
		putchar(' ');putchar(' ');putchar(i==optX&&j==optY?'<':' ');
		return;
	}
	color(gMap[i][j].ownPlayer%16==7?0:7,gMap[i][j].ownPlayer%16);
	switch (gMap[i][j].landKind) {
		case normalLand: {
			PrintArmyCount(gMap[i][j].armyCount);
			break;
		}
		case city: {
			color(5,gMap[i][j].ownPlayer%16);
			PrintArmyCount(gMap[i][j].armyCount);
			break;
		}
		case playerCapital: {
			color(4,gMap[i][j].ownPlayer%16);
			PrintArmyCount(gMap[i][j].armyCount);
			break;
		}
		case waLand: {
			color(14,gMap[i][j].ownPlayer%16);
			PrintArmyCount(gMap[i][j].armyCount);
			break;
		}
		case mountLand: {
			color(0,7); 
			putchar('/');putchar('\\');if(!(i==optX&&j==optY))putchar('^');
			break;
		}
		case tower: {
			color(6,gMap[i][j].ownPlayer%16);
			PrintArmyCount(gMap[i][j].armyCount);
			break;
		}
		default: {
			color(7,0);
			PrintArmyCount(gMap[i][j].armyCount);
			break;
		}
	}
	if(i==optX&&j==optY)putchar('<');
	else if(gMap[i][j].landKind!=mountLand)putchar(' ');
}
void GetArmyCounts() {
	totalArmy=0;
	memset(armyCount,0,sizeof(armyCount));
	for(int i=1;i<=playerCount;i++){armyCount[i]=0;}
	for(int i=1; i<=mSize; i++) {
		for(int j=1; j<=mSize; j++) {
			armyCount[gMap[i][j].ownPlayer]+=gMap[i][j].armyCount;
			totalArmy+=gMap[i][j].armyCount;
		}
	}
}
void GetLandCounts() {
	memset(landCount,0,sizeof(armyCount));
	for(int i=1; i<=mSize; i++) {
		for(int j=1; j<=mSize; j++) {
			landCount[gMap[i][j].ownPlayer]++;
		}
	}
	totalLand=mSize*mSize;
}
void PrintMap() {
	LoadWarFog();
	GetArmyCounts();
	GetLandCounts();
	LoadHisMap();
	float armyPer=(float)armyCount[1]/(float)totalArmy,landPer=(float)landCount[1]/(float)totalLand;
	gotoxy(0,0);
	for(int i=1; i<=mSize; i++) {
		for(int j=1; j<=mSize; j++) {
			PrintLand(i,j);
		}
		putchar('\n');
	}
	color(7,0);
	printf("�غ���:%d        ������:%d         \n�ܱ���: %d       �˵�Ԫ�����: %d         ��������: %d        \n",
	nCount,landCount[1],armyCount[1],gMap[optX][optY].armyCount,aliveAiCount);
	printf("��ӵ��ȫͼ %.2f%% �ľ��Ӻ� %2.f%% ������\n",armyPer*100,landPer*100);
	printf("�����ݵصĳɱ�Ϊ %d,������кͷ������ĳɱ�Ϊ %d,����ɽ�صĳɱ�Ϊ %d.\n"
	,Build_Land_Cost,Build_City_Cost,Break_Mount_Cost);
	color(aiHelp?2:4,0);
	printf(aiHelp?"AI������":"AI����ر�");
}
void PlayerKill(int k,int d) {
	for(int i=1; i<=mSize; i++) {
		for(int j=1; j<=mSize; j++) {
			if(gMap[i][j].ownPlayer==d){
				gMap[i][j].ownPlayer=k;
				if(i!=capitalX[d]&&j!=capitalY[d])gMap[i][j].armyCount/=2;
			}
			gMap[capitalX[d]][capitalY[d]].landKind=city;
		}
	}
	aliveAiCount--;
	LoadWarFog(); 
}
void ArmyMove(int x,int y,int dx,int dy) {
	if(gMap[dx][dy].landKind==mountLand){
		int temp=gMap[x][y].armyCount;
		if(gMap[x][y].armyCount>Break_Mount_Cost){
			gMap[dx][dy].landKind=normalLand;
			gMap[dx][dy].ownPlayer=gMap[x][y].ownPlayer;  
			gMap[x][y].armyCount-=Break_Mount_Cost;
		}
		else{
			gMap[x][y].armyCount=temp;
		}
		return;
	}
	if(gMap[x][y].armyCount==0)return;
	if(gMap[x][y].ownPlayer==gMap[dx][dy].ownPlayer) {
		gMap[dx][dy].armyCount+=(gMap[x][y].armyCount-1);
	} else if(gMap[x][y].armyCount>gMap[dx][dy].armyCount) {
		gMap[dx][dy].armyCount=(gMap[x][y].armyCount-gMap[dx][dy].armyCount-1);
		if(dx==capitalX[gMap[dx][dy].ownPlayer]&&dy==capitalY[gMap[dx][dy].ownPlayer]) {
			PlayerKill(gMap[x][y].ownPlayer,gMap[dx][dy].ownPlayer);
		}
		gMap[dx][dy].ownPlayer=gMap[x][y].ownPlayer;
	} else {
		gMap[dx][dy].armyCount-=(gMap[x][y].armyCount-1);
	}
	gMap[x][y].armyCount=1;
}
void AiDfs(int p,int x,int y,int dx,int dy,int steps,bool endflag) {//dfs��·��,steps�����������
	aiTryCount++;
	if(x>mSize||y>mSize||x<0||y<0||landVis[x][y]||endflag||aiTryCount>1e4+(2e5/aliveAiCount))return;
	if(gMap[x][y].landKind==mountLand)return;
	if(x==dx&&y==dy) {
		endflag=1;
		return;
	}
	if(endflag)return;
	landVis[x][y]=1;
	if(x-steps+10>dx&&steps>35){landVis[x][y]=0;endflag=1;}
	aiPath[p].push_front((moveUnit) {x+1,y});
	AiDfs(p,x+1,y,dx,dy,steps+1,endflag);
	aiPath[p].pop_front();
	if(x-steps+10<dx&&steps>35){landVis[x][y]=0;endflag=1;}
	aiPath[p].push_front((moveUnit) {x-1,y});
	AiDfs(p,x-1,y,dx,dy,steps+1,endflag);
	aiPath[p].pop_front();
	if(y-steps+10<dy&&steps>35){landVis[x][y]=0;endflag=1;}
	aiPath[p].push_front((moveUnit) {x,y-1});
	AiDfs(p,x,y-1,dx,dy,steps+1,endflag);
	aiPath[p].pop_front();
	if(y-steps+10>dy&&steps>35){landVis[x][y]=0;endflag=1;}
	aiPath[p].push_front((moveUnit) {x,y+1});
	AiDfs(p,x,y+1,dx,dy,steps+1,endflag);
	aiPath[p].pop_front();
	landVis[x][y]=0;
}
void AiFindPath(int p,int x,int y,int dx,int dy) {
	memset(landVis,0,sizeof(landVis));
	aiTryCount=0; 
	AiDfs(p,x,y,dx,dy,0,0);//��һ�������p��(x,y)��(dx,dy)��·��.
}
void AiSuddenAttack(int p) {
	int maxarmy=-1,maxx=0,maxy=0;
	for(int i=1; i<=mSize; i++) {
		for(int j=1; j<=mSize; j++) {
			if(gMap[i][j].armyCount>maxarmy&&gMap[i][j].ownPlayer==p) {
				maxarmy=gMap[i][j].armyCount;
				maxx=i;
				maxy=j;//Ѱ��������
			}
		}
	}
	for(int i=1; i<=playerCount; i++) {
		if(i==p)continue;
		if(gMap[capitalX[i]][capitalY[i]].armyCount<0.75*maxarmy) {//͵Ϯ����,��������ƻ�
			AiFindPath(p,maxx,maxy,capitalX[i],capitalY[i]);
			return;
		}
	}
}
void AiCheckCapital(int p) {
	bool danger=0;
	int dis=0,maxarmy=0,fromx=-1,fromy=-1,dis1=0;
	for(int l1=capitalX[p]-6; l1<=capitalX[p]+6; l1++) {
		for(int l2=capitalY[p]-6; l2<=capitalY[p]+6; l2++) {
			if(l1<1||l2<1||l1>mSize||l2>mSize||danger)continue;
			if(gMap[l1][l2].ownPlayer!=p&&gMap[l1][l2].armyCount>
			        gMap[capitalX[p]][capitalY[p]].armyCount*1.2) {//��Σ��
				danger=1;
				dis=abs(l1-capitalX[p])+abs(l2-capitalY[p]);
				while(!aiPath[p].empty())aiPath[p].pop_back();//������мƻ�,�׶�����Ҫ
			}
		}
	}
	if(danger) {
		for(int l1=capitalX[p]-6; l1<=capitalX[p]+6; l1++) {
			for(int l2=capitalY[p]-6; l2<=capitalY[p]+6; l2++) {
				if(l1<1||l2<1||l1>mSize||l2>mSize||(l1==capitalX[p]&&l2==capitalY[p]))continue;
				if(gMap[l1][l2].ownPlayer==p&&gMap[l1][l2].armyCount>maxarmy) {
					dis1=abs(l1-capitalX[p])+abs(l2-capitalY[p]);
					if(dis1>dis)continue;//������
					maxarmy=gMap[l1][l2].armyCount;
					fromx=l1;
					fromy=l2;
				}
			}
		}
	}
	if(fromx!=-1&&fromy!=-1) {
		AiFindPath(p,fromx,fromy,capitalX[p],capitalY[p]);//��һ֧�����Ӿ�Ԯ
	}
}
void DoAiQueue(int p) {//ִ��AI��ִ�еĲ���
	int aiMoveCount=0;
	if(!aiPath[p].empty()) {
		while(!aiPath[p].empty()&&aiMoveCount<=aiLevel) {
			moveUnit temp=aiPath[p].back();
			aiPath[p].pop_back();
			ArmyMove(temp.x,temp.y,aiPath[p].back().x,aiPath[p].back().y);
			aiMoveCount++;
		}
	}
}
void AiExband(int k) {//AI��չ����
	int aiEndFlag=0;
	for(int i=1;i<=mSize;i++){
		if(aiEndFlag>=aiLevel)break;
		for(int j=1;j<=mSize;j++){
			if(gMap[i][j].ownPlayer!=k)continue;if(aiEndFlag>=aiLevel)break;
			if(gMap[i][j].armyCount>Build_City_Cost&&RandPer(8,i))BuildLand(i,j,1);
			if(gMap[i][j].armyCount>Build_City_Cost&&RandPer(2,j))BuildLand(i,j,2);
			if(gMap[i][j].ownPlayer!=k&&gMap[i][j+1].ownPlayer==k&&gMap[i][j-1].ownPlayer==k&&
			gMap[i+1][j].ownPlayer==k&&gMap[i-1][j].ownPlayer==k){
				if(gMap[i][j+1].armyCount>gMap[i][j-1].armyCount&&
				gMap[i][j+1].armyCount>gMap[i-1][j].armyCount&&gMap[i][j+1].armyCount>gMap[i+1][j].armyCount)
				{ArmyMove(i,j+1,i,j);}
				else if(gMap[i][j-1].armyCount>gMap[i][j+1].armyCount&&
				gMap[i][j-1].armyCount>gMap[i-1][j].armyCount&&gMap[i][j-1].armyCount>gMap[i+1][j].armyCount)
				{ArmyMove(i,j-1,i,j);}
				else if(gMap[i+1][j].armyCount>gMap[i][j+1].armyCount&&
				gMap[i+1][j].armyCount>gMap[i][j-1].armyCount&&gMap[i+1][j].armyCount>gMap[i-1][j].armyCount)
				{ArmyMove(i+1,j,i,j);}
				else{ArmyMove(i-1,j,i,j);}
				aiEndFlag+=1;
			}
			if(gMap[i+1][j].ownPlayer!=k&&gMap[i][j].armyCount>gMap[i+1][j].armyCount&&RandPer(8,aiEndFlag+nCount/i+time(NULL))) {
				if((gMap[i][j].armyCount>Break_Mount_Cost&&gMap[i+1][j].landKind==mountLand)||gMap[i+1][j].landKind!=mountLand){
					ArmyMove(i,j,i+1,j);
					aiEndFlag+=1;
				}
			}
			if(gMap[i-1][j].ownPlayer!=k&&gMap[i][j].armyCount>gMap[i-1][j].armyCount&&RandPer(10,aiEndFlag+i+j+nCount)) {
				if((gMap[i][j].armyCount>Break_Mount_Cost&&gMap[i-1][j].landKind==mountLand)||gMap[i-1][j].landKind!=mountLand){
					ArmyMove(i,j,i-1,j);
					aiEndFlag+=1;
				}
			}
			if(gMap[i][j+1].ownPlayer!=k&&gMap[i][j].armyCount>gMap[i][j+1].armyCount&&RandPer(12,aiEndFlag+j+nCount/2)) {
				if((gMap[i][j+1].armyCount>Break_Mount_Cost&&gMap[i][j+1].landKind==mountLand)||gMap[i][j+1].landKind!=mountLand){
					ArmyMove(i,j,i,j+1);
					aiEndFlag+=1;
				}
			}
			if(gMap[i][j-1].ownPlayer!=k&&gMap[i][j].armyCount>gMap[i][j-1].armyCount&&RandPer(14,aiEndFlag+nCount)) {
				if((gMap[i][j-1].armyCount>Break_Mount_Cost&&gMap[i][j-1].landKind==mountLand)||gMap[i][j-1].landKind!=mountLand){
					ArmyMove(i,j,i,j-1);
					aiEndFlag+=1;
				}
			}
		}
	} 
	for(int i=1; i<=mSize; i++) {
		if(aiEndFlag>=aiLevel)break;
		for(int j=1; j<=mSize; j++) {
			for(int len=1; len<=mSize/5; len++) {
				if(gMap[i][j].ownPlayer!=k)continue;
				else {
					if(gMap[i+len][j].ownPlayer==k&&gMap[i][j].armyCount>gMap[i+len][j].armyCount&&RandPer(2,i+nCount)) {
						ArmyMove(i,j,i+len,j);
						aiEndFlag+=1;
					}
					if(gMap[i-len][j].ownPlayer==k&&gMap[i][j].armyCount>gMap[i-len][j].armyCount&&RandPer(3,i/3+nCount)) {
						ArmyMove(i,j,i-len,j);
						aiEndFlag+=1;
					}
					if(gMap[i][j+len].ownPlayer==k&&gMap[i][j].armyCount>gMap[i][j+len].armyCount&&RandPer(4,j/2+i+nCount)) {
						ArmyMove(i,j,i,j+len);
						aiEndFlag+=1;
					}
					if(gMap[i][j-len].ownPlayer==k&&gMap[i][j].armyCount>gMap[i][j-len].armyCount&&RandPer(5,aiEndFlag+j)) {
						ArmyMove(i,j,i,j-len);
						aiEndFlag+=1;
					}
				}
			}
		}
	}
}
void AiDecide() {
	for(int i=aiHelp?1:2; i<=playerCount; i++) {
		if(aiPath[i].empty())AiSuddenAttack(i);
		AiCheckCapital(i);
		DoAiQueue(i);
		AiExband(i);
	}
}
void SpawnNewPlayer(int x,int y){
	aliveAiCount++;
	if(gMap[x][y].landKind==playerCapital)return;
	playerCount++; 
	gMap[x][y].landKind=playerCapital;
	gMap[x][y].ownPlayer=playerCount;
	capitalX[playerCount]=x;capitalY[playerCount]=y;
	gMap[x][y].armyCount+=nCount*citySpeed*min(10,max(1,aiLevel-2))/3;
	int size=1+mSize/(Randn(nCount+time(NULL))%4+3); 
	for(int l1=-size;l1<=size;l1++){
		for(int l2=-size;l2<=size;l2++){
			if(gMap[x+l1][y+l2].landKind==playerCapital||gMap[x+l1][y+l2].landKind==mountLand)continue;
			if(x+l1>mSize||x+l1<1||y+l2>mSize||y+l2<1)continue;
			if((int)Randn(playerCount+l2+l1)%100<=(int)(95+size*4-(abs(l1)+abs(l2))*10)){
				gMap[x+l1][y+l2].ownPlayer=playerCount;
			}
		}
	}
}
void SpawnNewPlayers(){
	GetLandCounts();
	int x=Randn(playerCount)%mSize+1,y=Randn(nCount)%mSize+1;
	if(RandPer(1,nCount)&&RandPer(30,nCount*nCount)&&nCount>150)SpawnNewPlayer(x,y);
}
void gMove(int x,int y) {
	optX=x;
	optY=y;
}
void BuildLand(int x,int y,int kind) {
	int temp=gMap[x][y].armyCount;
	if(gMap[x][y].landKind==waLand&&temp>citySpeed*10+nCount/landSpeed) {
		if(kind==1)gMap[x][y].landKind=normalLand;
		if(kind==2)gMap[x][y].landKind=mountLand;
		temp-=Build_Land_Cost;
	} else if(gMap[x][y].landKind==normalLand&&temp>citySpeed*100+nCount*2/landSpeed) {
		if(kind==1)gMap[x][y].landKind=city;
		if(kind==2)gMap[x][y].landKind=tower;
		temp-=Build_City_Cost;
	}
	gMap[x][y].armyCount=temp;
}
void LoadWarFog() {
	memset(warFog,ifFog?0:1,sizeof(warFog));
	for(int i=1; i<=mSize; i++) {
		for(int j=1; j<=mSize; j++) {
			if(gMap[i][j].ownPlayer==1) {
				warFog[i][j]=warFog[i-1][j]=warFog[i+1][j]=warFog[i][j-1]=
				warFog[i][j+1]=warFog[i-1][j-1]=warFog[i-1][j+1]=warFog[i+1][j-1]=warFog[i+1][j+1]=1;
			}
		}
	}
}
void DoAiAndMap(){
	AiDecide();
	PrintMap();
} 
void PlayerDo(bool only) {
	if(optX>mSize||optY>mSize||optX<1||optY<1) {
		int temp=gMap[optX][optY].armyCount;
		gMap[optX][optY].armyCount=0;
		while(optX>mSize)optX--;
		while(optY>mSize)optY--;
		while(optX<1)optX++;
		while(optY<1)optY++;
		gMap[optX][optY].armyCount=temp;
		nCount++;
		gPlus();
		PlayerDo(0);
	}
	if(nowCount!=nCount){
		SpawnNewPlayers();
		nowCount=nCount;
	}
	if(GameEnd()!=2)return;
	if(!only)DoAiAndMap();
	bool halfArmy=0;	
	int tq=getch();
	int x=optX,y=optY,temp=0;
	int For1[8]={72,80,75,77},For2[8]={'d','a','w','s','D','A','W','S'};
	int Mov1[8]={-1,1,0,0,0,0,-1,1},Mov2[16]={0,0,-1,1,0,0,-1,1,1,-1,0,0,1,-1,0,0};
	if(tq==224) {
		tq=getch();
		for(int i=0;i<4;i++) {
			if(tq==For1[i]) {
				gMove(x+Mov1[i],y+Mov1[i+4]);
				PrintMap();
				PlayerDo(1);
				return;
			}
		}
	}
	if(tq=='q'){
		aiHelp=aiHelp?0:1;
		PrintMap();
		PlayerDo(1);
		return;
	}
	else if(tq=='y'){
		SaveMap();
	}
	else if(tq=='e'){
		EditLand(optX,optY);
		PlayerDo(1);return;
	}
	else if(tq=='d'&&!aiHelp) {
		if(gMap[x][y+1].landKind==mountLand&&gMap[x][y].armyCount<=Break_Mount_Cost)return; 
		gMove(x,y+1);
	}
	else if(tq=='a'&&!aiHelp) {
		if(gMap[x][y-1].landKind==mountLand&&gMap[x][y].armyCount<=Break_Mount_Cost)return; 
		gMove(x,y-1);
	}
	else if(tq=='w'&&!aiHelp) {
		if(gMap[x-1][y].landKind==mountLand&&gMap[x][y].armyCount<=Break_Mount_Cost)return; 
		gMove(x-1,y);
	}
	else if(tq=='s'&&!aiHelp) {
		if(gMap[x+1][y].landKind==mountLand&&gMap[x][y].armyCount<=Break_Mount_Cost)return; 
		gMove(x+1,y);
	}
	else if(tq=='D'&&!aiHelp) {
		halfArmy=1;
		if(gMap[x][y+1].landKind==mountLand&&gMap[x][y].armyCount/2<=Break_Mount_Cost)return; 
		gMove(x,y+1);
	}
	else if(tq=='A'&&!aiHelp) {
		halfArmy=1;
		if(gMap[x][y-1].landKind==mountLand&&gMap[x][y].armyCount/2<=Break_Mount_Cost)return; 
		gMove(x,y-1);
	}
	else if(tq=='W'&&!aiHelp) {
		halfArmy=1;
		if(gMap[x-1][y].landKind==mountLand&&gMap[x][y].armyCount/2<=Break_Mount_Cost)return; 
		gMove(x-1,y);
	}
	else if(tq=='S'&&!aiHelp) {
		if(gMap[x+1][y].landKind==mountLand&&gMap[x][y].armyCount/2<=Break_Mount_Cost)return; 
		halfArmy=1;
		gMove(x+1,y);
	}
	else if(tq=='o'&&!aiHelp) {
		BuildLand(x,y,1);
	}
	else if(tq=='p'&&!aiHelp) {
		BuildLand(x,y,2);
	}
	else if(tq!='m'){
		nCount++;PlayerDo(1);return;
	}
	nCount++;
	gPlus();
	if(gMap[x][y].ownPlayer==1){
		if(halfArmy) {
		if(gMap[x][y].armyCount%2==1)gMap[x][y].armyCount++;
			gMap[x][y].armyCount/=2;
			temp=gMap[x][y].armyCount;
		}
		ArmyMove(x,y,optX,optY);
		if(halfArmy)gMap[x][y].armyCount=temp;
	}
	PlayerDo(0);
}
void gPlus() {
	int tCount;
	for(int i=1; i<=mSize; i++) {
		for(int j=1; j<=mSize; j++) {
			if(gMap[i][j].ownPlayer==0)continue;
			if(gMap[i][j].landKind==city||gMap[i][j].landKind==playerCapital) {
				gMap[i][j].armyCount+=citySpeed;
				if(gMap[i][j].ownPlayer!=1&&aiLevel>=4)gMap[i][j].armyCount+=citySpeed*min(10,aiLevel-2);
			}
			if(gMap[i][j].landKind==waLand&&gMap[i][j].ownPlayer>1&&aiLevel>=3&&nCount%landSpeed==0){
				gMap[i][j].armyCount++;
			}
			if(gMap[i][j].landKind==tower&&gMap[i][j].ownPlayer!=0) {
				if(gMap[i][j].ownPlayer!=1&&aiLevel>=6&&nCount%landSpeed==0)gMap[i][j].armyCount++; 
				tCount=0;
				for(int l1=i-4; l1<=i+4; l1++) {
					if(tCount>15)break;
					for(int l2=j-4; l2<=j+4; l2++) {
						if((l1==i&&l2==j)||(l1<1||l2<1||l1>mSize||l2>mSize)||tCount>4)continue;
						if(gMap[i][j].ownPlayer!=gMap[l1][l2].ownPlayer&&RandPer(15,l1+l2)) {
							gMap[l1][l2].armyCount-=citySpeed*(3+nCount/97);
							tCount++;
							if(gMap[l1][l2].armyCount<0)gMap[l1][l2].armyCount=0;
						}
					}
				}
			} else if(gMap[i][j].landKind==normalLand&&nCount%landSpeed==0) {
				gMap[i][j].armyCount++;
				if(gMap[i][j].ownPlayer!=1&&aiLevel>=4)gMap[i][j].armyCount+=min(10,aiLevel-2);
			} else if(gMap[i][j].landKind==waLand&&gMap[i][j].armyCount-citySpeed>=0){
				if(aiLevel>=3&&gMap[i][j].ownPlayer!=1)continue;
				else gMap[i][j].armyCount-=citySpeed;
			}
		}
	}
}
void LoadHisMap(){
	memset(needRef,1,sizeof(needRef));
	for(int i=1;i<=mSize;i++){
		for(int j=1;j<=mSize;j++){
			if(lMap[i][j]==gMap[i][j]&&nCount>0)needRef[i][j]=0;
			if(lFog[i][j]==0&&warFog[i][j]==0&&nCount>0)needRef[i][j]=0;
			lMap[i][j]=gMap[i][j];
			lFog[i][j]=warFog[i][j];
		}
	}
	for(int i=-3;i<=3;i++){
		for(int j=-3;j<=3;j++){
			needRef[optX+i][optY+j]=1;
		}
	}
}
void SaveMap(){
	backFromSave=1;
	system("cls");
	int save_slot;
	string save_name;
	printf("��Ҫ�������ͼ�洢���ĸ��浵��(1-3)�����������ֽ��᷵����Ϸ��\n");
	cin>>save_slot;
	printf("����������浵�����ơ�\n");
	cin>>save_name;
	string temp="IAKIOI";
	if(save_slot==1)temp=save1;
	else if(save_slot==2)temp=save2;
	else if(save_slot==3)temp=save3;
	else GameMain();
	ofstream save(temp);
	save<<save_name<<endl<<mSize<<" "<<ifEnd<<" "<<ifFog<<" "<<playerCount<<" "
		<<citySpeed<<" "<<landSpeed<<" "<<aiLevel<<" "<<optX<<" "<<optY<<" "<<nCount<<" "<<aiHelp<<" "<<aliveAiCount<<"\n"; 
	for(int i=1;i<=playerCount;i++){
		save<<capitalX[i]<<" "<<capitalY[i]<<"\n";
	}
	for(int i=1;i<=mSize;i++){
		for(int j=1;j<=mSize;j++){
			save<<gMap[i][j].armyCount<<" "<<gMap[i][j].landKind<<" "<<gMap[i][j].ownPlayer<<" "<<landVis[i][j]<<"    ";
		}
		save<<"\n";
	}
	Menu();
}
void LoadMap(){
	color(7,0);
	system("cls");
	backFromSave=1;
	int save_slot;
	string save_name;
	printf("��Ҫ��ȡ�ĸ��浵��(1-3)�����������ֽ��᷵�����˵���\n");
	cin>>save_slot;
	string temp="IAKIOI";
	if(save_slot==1)temp=save1;
	else if(save_slot==2)temp=save2;
	else if(save_slot==3)temp=save3;
	else Menu();
	ifstream read(temp);
	read>>save_name>>mSize>>ifEnd>>ifFog>>playerCount>>citySpeed>>landSpeed>>aiLevel>>optX>>optY>>nCount>>aiHelp>>aliveAiCount;
	if(save_name==""){
		color(4,15);
		cout<<"���󣺴浵�𻵻�Ϊ�ա�\n";
		Sleep(1000);
		LoadMap();
	}
	cout<<"��Ҫ��ȡ������Ϊ "<<save_name<<" �Ĵ浵��(��Y/N)\n";
	char input=getch();
	if(input!='Y'&&input!='y')LoadMap(); 
	for(int i=1;i<=playerCount;i++){
		read>>capitalX[i]>>capitalY[i];
	}
	for(int i=1;i<=mSize;i++){
		for(int j=1;j<=mSize;j++){
			read>>gMap[i][j].armyCount>>gMap[i][j].landKind>>gMap[i][j].ownPlayer>>landVis[i][j];
		}
	}
}
void EditLand(int x,int y){
	color(0,7); 
	gotoxy(0,mSize*3+4);
	int army=gMap[x][y].armyCount,kind=gMap[x][y].landKind,own=gMap[x][y].ownPlayer;
	printf("�õؿ���Ϣ��");gotoxy(1,mSize*3+4);
	printf("1.����������%d,2.�������ࣺ%d,3.������ң�%d",army,kind,own);gotoxy(2,mSize*3+4);
	printf("��(1-3)������Ҫ�޸ĵ���ֵ����f��ɸ��ġ�");gotoxy(3,mSize*3+4); 
	printf("ע���������ͱ��(1-6),1.��ͨ���� 2.�ݵ� 3.���� 4.�׶� 5.ɽ�� 6.������ ");gotoxy(4,mSize*3+4);
	char input=getch();
	printf("���룺");
	if(input=='1')cin>>gMap[x][y].armyCount;
	else if(input=='2'){
		cin>>gMap[x][y].landKind;
		if(gMap[x][y].landKind==playerCapital){
			gMap[capitalX[gMap[x][y].ownPlayer]][capitalY[gMap[x][y].ownPlayer]].landKind=city;
			capitalX[gMap[x][y].ownPlayer]=x;capitalY[gMap[x][y].ownPlayer]=y;
		}
	}
	else if(input=='3')cin>>gMap[x][y].ownPlayer;
	color(7,0);
	gotoxy(0,mSize*3+4);printf("                                                                              ");
	gotoxy(1,mSize*3+4);printf("                                                                              ");
	gotoxy(2,mSize*3+4);printf("                                                                              ");
	gotoxy(3,mSize*3+4);printf("                                                                              ");
	gotoxy(4,mSize*3+4);printf("                                                                              ");
	needRef[x][y]=1;PrintLand(x,y);
}
void Menu(){
	color(7,0);
	system("cls");
	cout<<"��ӭ������C2OI-������ս����Ϸ�汾����ʽ1.0.2��\n";
	cout<<"����1�鿴����ָ�ϣ�����2��ʼ�����Ϸ������3��ȡ��Ĵ浵��\n";
	char ccf_horse_dies=getch();
	bool tflag=0;
	if(ccf_horse_dies=='1'&&!tflag){
		tflag=1;
		color(4,15);
		cout<<
		"����ϸ�Ķ��������ݣ�\n"
		"��ϷĿ�꣺��ռ�������˵��׶�����ɫ���壩��\n"
		"��Ϸ���ƣ����С����������������������ڵ��˼��ɹ�ռ���ء�\n" 
		"����ָ��:\n"
		"1.wasd�����ƶ�\n"
		"2.shift+wasd��һ����ƶ�\n"
		"3.�������Ҽ�ֻ�ƶ����,�ڹ¾����˾��ڱ������ʱ����Բ��˷ѻغ��ƻ��Լ��ľ���\n"
		"4.O�����θ���Ϊ�����͵���(�ݵ�->����,����->����),��Ҫ�㹻����,����������ᱻ����!\n"
		"5.P�����θ���Ϊ�����Ե���(�ݵ�->�ϰ�,����->������),��Ҫ�㹻����,����������ᱻ����!\n"
		"6.��ɫ�������׶�,��ɫ�����ǳ���,����ɫ�������ݵ�,��ɫ�����Ƿ�����.\n"
		"7.�׶�/���п�����������,����������������,�ݵؿ��ٿ۱�,����������һ����Χ�ڵĵ��˵�Ԫ��\n"
		"9.200�غϺ��и���ˢ�������(�Ѿ�)�� \n"
		"8.��ʧ�׶�ʧ��,��ռ��������AI�׶���ʤ.\n"
		"9.��q����AI����(֮����԰�m���غ�)\n"
		"10.��y�浵\n"
		"�����ɿ�40��ͼ100AI;�������ÿɿ�60��ͼ<1000AI��\n"; 
		system("pause");
		Menu();
	}
	else if(ccf_horse_dies=='2'){
		GameStart();
		GameMain();
	}
	else if(ccf_horse_dies=='3'){
		LoadMap();
		GameMain();
	}
} 
int GameEnd() {
	if(!ifEnd)return 2;
	if(gMap[capitalX[1]][capitalY[1]].ownPlayer!=1)return 0;
	bool flag=1;
	for(int i=1; i<=playerCount; i++)if(gMap[capitalX[i]][capitalY[i]].ownPlayer!=1)flag=0;
	if(flag)return 1;
	else return 2;
}
void GameMain() {
	system("cls");
	if(!backFromSave){
		optX=optY=1;
		gInit();
	}
	LoadWarFog();
	PrintMap();
	do{PlayerDo(0);}while(GameEnd()==2);
	system("cls");
	if(GameEnd()==0){
		printf("\nYou lose!");
	}
	else if(GameEnd()==1){
		printf("\nYou win!");
	}
	system("pause >nul");
}
signed main() {
	char consoleTitle[39]="C2OI-Warlords Public Release 1.0.2";
	SetConsoleTitle(consoleTitle);
	HideCursor();
	Menu();
}
