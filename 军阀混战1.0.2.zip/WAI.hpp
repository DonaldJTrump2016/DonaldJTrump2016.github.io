//ONLY USED FOR C2OI-WARLORDS. DO NOT EDIT! 
#include <windows.h>
#include <conio.h>
#define normalLand 1
#define waLand 2
#define city 3
#define playerCapital 4
#define mountLand 5
#define tower 6
#define Build_City_Cost citySpeed*100+nCount*2/landSpeed+nCount*citySpeed/10
#define Build_Land_Cost citySpeed*10+nCount/landSpeed+nCount*citySpeed/50
#define Break_Mount_Cost citySpeed*200+nCount*4/landSpeed+nCount*citySpeed/5
#define DEBUG system("cls");puts("I AK IOI");
void gotoxy(int x,int y) {
	COORD c;
	c.X=y;
	c.Y=x;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);
}
void color(int t,int b) {
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),t+b*16);
}
void HideCursor(){
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO CursorInfo;
	GetConsoleCursorInfo(handle,&CursorInfo);
	CursorInfo.bVisible = false; 
	SetConsoleCursorInfo(handle,&CursorInfo);
}
/*
void Start(){
    setbkcolor(EGERGB(0x15,0xAA,0xFF));
    setcolor(EGERGB(0xFF,0x15,0x0));
    setfont(100,0,"����");
    settextjustify(LEFT_TEXT,TOP_TEXT);
    outtextxy(90,350,"C2OI Code & Games Studios");
    Sleep(1500);
    cleardevice();
}
void menu(){
	PIMAGE backGround=newimage();
	getimage(backGround,"Empires_menu.jpg");
	putimage(0,0,backGround);
	setfont(80,0,"����");
	settextjustify(LEFT_TEXT,TOP_TEXT);
	outtextxy(420,0,"C2OI's Warlords");
	setfont(50,0,"��Բ");
	mouse_msg msg={0};
	for(;is_run();delay_fps(30)){
		while(mousemsg()){
			msg=getmouse();
		}
		if(msg.x>=500&&msg.x<=920&&msg.y>=325&&msg.y<=485){;
			setfillcolor(EGERGB(0xFF,0x88,0xFF));
			setfontbkcolor(EGERGB(0xFF,0x88,0xFF));
			bar(500,325,920,485);
			outtextxy(610,375,"��ʼ��Ϸ");
		}
		else{
			setfillcolor(EGERGB(0xFF,0x0,0xFF));
			setfontbkcolor(EGERGB(0xFF,0x0,0xFF));
			setcolor(EGERGB(0x0,0x0,0x0));
			bar(500,325,920,485);
			outtextxy(610,375,"��ʼ��Ϸ");
		}
		if(msg.is_down()){
			return;
		}
	}
}*/
