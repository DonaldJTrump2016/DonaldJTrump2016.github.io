# 简体中文
* 	C2OI 军阀混战
* 	灵感: generals.io（75%） | 席德·梅尔的文明（25%）
* 	程序: JoeBiden2020
* 	平台: Windows
*   	编译参数: -fno-asm -march=native -Ofast -m64 -pipe -static-libgcc -std=c++11 -Wall -lm -Wl,-stack=1073741824
*   	最新版本: 正式版1.0.0
* 	更新日期: 2022/2/18
* 	bug反馈: 私聊https://www.luogu.com.cn/user/432183
*   	确认你的编译器支持thread且你的硬件支持多线程
* 	Copyright (c) 2021-2022 C2OI Code&Game Studios | JoeBiden2020, All rights reserved.
* 	仅在洛谷和 Github 发布
# English
* 	C2OI Warlords
* 	Idea: generals.io（75%） | Sid Meier's Civilizations （15%）
* 	Code: JoeBiden2020
* 	Platform: Windows
* 	compile arguments: -fno-asm -march=native -Ofast -m64 -pipe -static-libgcc -std=c++11 -Wall -lm -Wl,-stack=1073741824
* 	Latest Version: Public Release 1.0.0
* 	Update: 2022/2/18
* 	Bug report: https:https://www.luogu.com.cn/user/432183
* 	Make sure your compiler and your hardware supports thread
* 	Copyright (c) 2021-2022 C2OI Code&Game Studios | JoeBiden2020, All rights reserved.
* 	Only published on Luogu and Github